package com.p10.core.entities;

public abstract class CollisionResponse {
	public void resolveCollision(CollidableEntity e1, CollidableEntity e2) {

	}
}
