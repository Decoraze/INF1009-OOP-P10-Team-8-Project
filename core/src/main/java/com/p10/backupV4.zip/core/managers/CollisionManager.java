package com.p10.core.managers;

import java.util.ArrayList;
import java.util.List;

import com.p10.core.entities.CollidableEntity;
import com.p10.core.entities.CollisionDetection;
import com.p10.core.entities.CollisionResponse;
import com.p10.core.interfaces.iCollision;//added interfaced. 

/**
 * CollisionManager - Handles collision detection
 * 1
 */
public class CollisionManager implements iCollision {
    private CollisionDetection detector;
    private CollisionResponse responder;

    public CollisionManager() {
        // detector and responder are abstract — need concrete subclasses to instantiate
        // For now, left as null until concrete implementations are created
        System.out.println("[CollisionManager] Stub initialized");
    }

    public void checkCollisions(List<CollidableEntity> collidableEntities) {// changed object collidable entity wrapper
                                                                            // to CollidableEntity rather than
                                                                            // Entity(generic)
        for (int i = 0; i < collidableEntities.size(); i++) {
            for (int j = i + 1; j < collidableEntities.size(); j++) {
                CollidableEntity e1 = collidableEntities.get(i);
                CollidableEntity e2 = collidableEntities.get(j);
                if (checkCollision(e1, e2)) {
                    System.out.println("[CollisionManager] Collision detected: " + e1.getId() + " <-> " + e2.getId());
                    e1.onCollisionEnter(e2);
                    e2.onCollisionEnter(e1);
                }
            }
        }
    }

    public void addCollidable(CollidableEntity e) {
        // delegates to detector internally
        if (detector != null)
            detector.addCollidable(e);
    }

    public boolean checkCollision(CollidableEntity e1, CollidableEntity e2) { // since we are using a collidable entity
                                                                              // list we use collidable rather than
                                                                              // boolean mb on this part
        return e1.getHitbox().overlaps(e2.getHitbox());
    }

    public List<CollidableEntity> getCollidables() {
        return new ArrayList<CollidableEntity>(); // Get CollidableEntity list from iCollision interface
    }

    public void dispose() {
        System.out.println("[CollisionManager] Stub disposed");
    }
}