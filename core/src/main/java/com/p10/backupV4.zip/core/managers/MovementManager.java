package com.p10.core.managers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.p10.core.entities.Entity;
import com.p10.core.interfaces.iInput;
import com.p10.core.interfaces.iMovement;
import com.p10.core.movement.AIMovement;
import com.p10.core.movement.PlayerMovement;

/**
 * MovementManager - Updates entity positions
 * 
 */
public class MovementManager implements iMovement {// added iMovement implementation for interface
    private PlayerMovement playerMovement; // two movements
    private Map<String, AIMovement> aiMovements; // two movements abstract

    public MovementManager() {
        this.playerMovement = new PlayerMovement();// init player movement
        this.aiMovements = new HashMap<>();// init movement for hashmap for AI usage
        System.out.println("[MovementManager] Stub initialized");
    }

    // TBC (for whole list of entity or ?)
    public void applyMovement(Entity entity, float dt) {
        if (!aiMovements.containsKey(entity.getId())) {
            aiMovements.put(entity.getId(), new AIMovement());
            System.out.println("[MovementManager] Created AIMovement for: " + entity.getId());
        }
        aiMovements.get(entity.getId()).update(entity, dt);
    }

    public void applyPhysics(Entity entity, float dt) {
        entity.update(dt);
    }

    // update player movement
    public void applyPlayerMovement(Entity entity, float dt, iInput input) {
        playerMovement.update(entity, dt, input);
    }

    public void dispose() {
        aiMovements.clear();
        System.out.println("[MovementManager] Disposed");
    }

    public void updateMovement(List<Entity> entities, float dt) {
        for (Entity e : entities) {
            applyMovement(e, dt);
        }
    }
}