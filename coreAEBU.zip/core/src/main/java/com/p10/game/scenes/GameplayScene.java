package com.p10.game.scenes;

import java.util.ArrayList;
import java.util.List;

import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.p10.core.entities.Entity;
import com.p10.core.interfaces.*;
import com.p10.core.scene.Scene;
import com.p10.game.ai.EnemyAI;
import com.p10.game.ai.PathDefinition;
import com.p10.game.ai.TowerAI;
import com.p10.game.entities.Enemy;
import com.p10.game.entities.Projectile;
import com.p10.game.entities.Server;
import com.p10.game.entities.Tower;
import com.p10.game.grid.GameCollisionHandler;
import com.p10.game.grid.GridManager;
import com.p10.game.grid.TowerPlacer;
import com.p10.game.ui.EduPopup;
import com.p10.game.ui.HUD;
import com.p10.game.wave.GameState;
import com.p10.game.wave.LevelConfig;
import com.p10.game.wave.WaveManager;

/**
 * GameplayScene is the main game scene — handles the full game loop:
 * prep phase (buy/place towers) → wave phase (enemies spawn, towers fire) → repeat.
 *
 * Game flow:
 * 1. onLoad: initialize grid, path, AI, state, spawn server
 * 2. update: edu popup → game over check → win check → HUD input → prep/wave logic
 * 3. render: grid → entities → HUD → popups → game over overlay
 *
 * @owner Hui Yang
 */
public class GameplayScene extends Scene {
    private LevelConfig levelConfig;
    private GridManager gridManager;
    private TowerPlacer towerPlacer;
    private GameCollisionHandler collisionHandler;
    private WaveManager waveManager;
    private GameState gameState;
    private EnemyAI enemyAI;
    private TowerAI towerAI;
    private PathDefinition path;
    private HUD hud;
    private EduPopup eduPopup;
    private Server server;
    private float screenW, screenH;

    // Static field so LevelSelectScene can set which level to play
    private static LevelConfig selectedLevel = null;
    public static void setSelectedLevel(LevelConfig cfg) { selectedLevel = cfg; }

    public GameplayScene(iCollision collision, iEntityOps entityOps, iSceneControl sceneCtrl,
                         iInput input, iAudio audio, iMovement movement,
                         float screenW, float screenH) {
        super("GameplayScene", collision, entityOps, sceneCtrl, input, movement, audio);
        this.screenW = screenW;
        this.screenH = screenH;
    }

    @Override
    protected void onLoad() {
        // TODO: Get levelConfig from selectedLevel (default to level1_DDoS if null)
        // TODO: Initialize GridManager with levelConfig's grid layout
        // TODO: Build path from gridManager
        // TODO: Initialize EnemyAI, TowerAI, TowerPlacer, GameCollisionHandler
        // TODO: Initialize GameState with starting currency and lives
        // TODO: Initialize WaveManager with levelConfig's waves
        // TODO: Initialize HUD and EduPopup
        // TODO: Show edu popup with level name and educational text
        // TODO: Place Server entity at end of path
    }

    @Override
    protected void onUnload() {
        // TODO: Remove all game entities via entityOps
        // TODO: Dispose HUD and EduPopup
    }

    @Override
    public void update(float dt) {
        // TODO: Clean up inactive entities every frame
        // TODO: If edu popup visible, handle its input and return
        // TODO: If game over, wait for ENTER to go back to MainMenu
        // TODO: If all waves done, set game won
        // TODO: Handle HUD input (tower selection)
        // TODO: Handle tower placement
        // TODO: PREP PHASE: wait for SPACE to start wave
        // TODO: WAVE PHASE:
        //   - Update WaveManager (spawn enemies)
        //   - Gather enemies and towers from entity list
        //   - Run EnemyAI movement for each enemy
        //   - Run TowerAI targeting for each tower
        //   - Update all entities
        //   - Run GameCollisionHandler
        //   - Mark dead enemies as inactive
        // TODO: ESC to return to MainMenu
    }

    private void cleanupEntities() {
        // TODO: Remove all inactive entities from entityOps
    }

    @Override
    public void renderShapes(ShapeRenderer renderer) {
        // TODO: Render grid
        // TODO: Render tower range indicator if placing tower
        // TODO: Render HUD shapes
        // TODO: Render edu popup if visible
    }

    @Override
    public void renderTextures(SpriteBatch batch) {
        // TODO: Render HUD text
        // TODO: Render edu popup text if visible
        // TODO: Render game over / win overlay text
    }

    private String getNextWaveEnemyType() {
        // TODO: Return the enemy type of the current/next wave for HUD display
        return null;
    }

    @Override
    public void dispose() {
        // TODO: Dispose HUD and EduPopup
    }
}
