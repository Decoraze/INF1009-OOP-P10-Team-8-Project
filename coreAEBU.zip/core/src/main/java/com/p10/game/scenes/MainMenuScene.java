package com.p10.game.scenes;

import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.p10.core.interfaces.*;
import com.p10.core.scene.Scene;

/**
 * MainMenuScene displays the game title and menu options.
 * [1] or [ENTER] → LevelSelect, [H] → HelpScene
 *
 * @owner Hui Yang
 */
public class MainMenuScene extends Scene {
    private BitmapFont titleFont;
    private BitmapFont menuFont;
    private float screenW, screenH;

    public MainMenuScene(iCollision collision, iEntityOps entityOps, iSceneControl sceneCtrl,
                         iInput input, iAudio audio, iMovement movement,
                         float screenW, float screenH) {
        super("MainMenu", collision, entityOps, sceneCtrl, input, movement, audio);
        this.screenW = screenW;
        this.screenH = screenH;
    }

    @Override
    protected void onLoad() {
        // TODO: Initialize fonts (titleFont scale 3, menuFont scale 1.5)
    }

    @Override
    protected void onUnload() {
        // TODO: Dispose fonts
    }

    @Override
    public void update(float dt) {
        // TODO: NUM_1 or ENTER → switch to LevelSelect
        // TODO: H → switch to HelpScene
    }

    @Override
    public void renderShapes(ShapeRenderer renderer) {
        // TODO: Draw dark background
        // TODO: Draw decorative bar under title
    }

    @Override
    public void renderTextures(SpriteBatch batch) {
        // TODO: Draw "NETDEFENDER" title in cyan
        // TODO: Draw menu options
        // TODO: Draw "Team P10" footer
    }
}
