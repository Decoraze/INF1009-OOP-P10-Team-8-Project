package com.p10.game.ai;

import java.util.ArrayList;
import java.util.List;
import com.badlogic.gdx.math.Vector2;
import com.p10.core.entities.Entity;
import com.p10.core.interfaces.iEntityOps;
import com.p10.game.entities.Enemy;
import com.p10.game.entities.Projectile;
import com.p10.game.entities.Tower;

/**
 * TowerAI handles tower targeting and firing logic.
 * Each frame: find enemies in range, pick target via TargetStrategy,
 * fire a Projectile if cooldown is ready.
 *
 * @owner Aurelius
 */
public class TowerAI {
    private int projectileCounter = 0;

    /**
     * Update a single tower — find targets, fire projectiles.
     * @param tower       The tower to update
     * @param allEnemies  All active enemies in the game
     * @param dt          Delta time
     * @param entityOps   Engine interface to add new entities (projectiles)
     */
    public void update(Tower tower, List<Enemy> allEnemies, float dt, iEntityOps entityOps) {
        // TODO: If tower is inactive, return
        // TODO: Call tower.update(dt) to tick cooldown
        // TODO: Build list of enemies within tower's range (use distance check)
        // TODO: If no enemies in range, return
        // TODO: Use TargetStrategy.pickTarget() to select best target
        // TODO: If tower canFire(), create a Projectile aimed at target
        //       - Calculate direction vector from tower to target
        //       - Apply tower.getDamageMultiplier(target) to tower.getDamage()
        //       - Add projectile via entityOps.addEntity()
        //       - Reset tower cooldown
    }

    private float dst(float x1, float y1, float x2, float y2) {
        // TODO: Euclidean distance
        return 0f;
    }
}
