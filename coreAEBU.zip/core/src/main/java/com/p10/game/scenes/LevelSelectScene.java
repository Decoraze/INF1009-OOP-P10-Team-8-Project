package com.p10.game.scenes;

import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.p10.core.interfaces.*;
import com.p10.core.scene.Scene;
import com.p10.game.wave.LevelConfig;

/**
 * LevelSelectScene displays 4 level options for the player to choose from.
 * Keys 1-4 select a level, ESC goes back to MainMenu.
 *
 * @owner Hui Yang
 */
public class LevelSelectScene extends Scene {
    private BitmapFont titleFont;
    private BitmapFont font;
    private float screenW, screenH;

    public LevelSelectScene(iCollision collision, iEntityOps entityOps, iSceneControl sceneCtrl,
                            iInput input, iAudio audio, iMovement movement,
                            float screenW, float screenH) {
        super("LevelSelect", collision, entityOps, sceneCtrl, input, movement, audio);
        this.screenW = screenW;
        this.screenH = screenH;
    }

    @Override
    protected void onLoad() {
        // TODO: Initialize fonts (titleFont scale 2, font scale 1.2)
    }

    @Override
    protected void onUnload() {
        // TODO: Dispose fonts
    }

    @Override
    public void update(float dt) {
        // TODO: NUM_1 → set level1_DDoS, switch to GameplayScene
        // TODO: NUM_2 → set level2_Virus, switch to GameplayScene
        // TODO: NUM_3 → set level3_Phishing, switch to GameplayScene
        // TODO: NUM_4 → set level4_Mixed, switch to GameplayScene
        // TODO: ESC → switch to MainMenu
    }

    @Override
    public void renderShapes(ShapeRenderer renderer) {
        // TODO: Draw dark background
        // TODO: Draw 4 colored level selection boxes
    }

    @Override
    public void renderTextures(SpriteBatch batch) {
        // TODO: Draw title "SELECT LEVEL"
        // TODO: Draw level labels with descriptions and key hints
        // TODO: Draw ESC hint
    }
}
